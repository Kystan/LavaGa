﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Lalkakkkkaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
{

    public partial class Form1 : Form
    {

        public Form1()
        {
            this.FormClosing += Form1_FormClosing;
            InitializeComponent();
            FillStudentList();

        }

        private void FillStudentList()
        {
            listBox1.Items.Add("Иванов Иван Иванович");
            listBox1.Items.Add("Петров Петр Петрович");
            listBox1.Items.Add("Сидоров Сидор Сидорович");
            listBox1.Items.Add("Алексеев Алексей Алексеевич");
            listBox1.Items.Add("Николаев Николай Николаевич");
            listBox1.Items.Add("Михайлов Михаил Михайлович");
            listBox1.Items.Add("Дмитриев Дмитрий Дмитриевич");
            listBox1.Items.Add("Андреев Андрей Андреевич");
            listBox1.Items.Add("Александров Александр Александрович");
            listBox1.Items.Add("Владимиров Владимир Владимирович");
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = MessageBox.Show("Закрыть?", "Message", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.No;
        }


        private void button3_Click(object sender, EventArgs e)
        {
            string firstName = textBox4.Text;
            string lastName = textBox5.Text;
            string middleName = textBox6.Text;

            if (IsAllLetters(firstName) && IsAllLetters(lastName) && IsAllLetters(middleName))
            {
                string fullName = $"{firstName} {lastName} {middleName}";
                listBox1.Items.Add(fullName);
            }
            else
            {
                MessageBox.Show("Имена должны содержать только буквы", "Ошибка");
            }
        }

        private bool IsAllLetters(string input)
        {
            foreach (char c in input)
            {
                if (!char.IsLetter(c))
                {
                    return false;
                }
            }
            return true;
        }


        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                string studentName = listBox1.SelectedItem.ToString();
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);

                ClearGrades();

                File.Delete($"C:\\Users\\Daniil\\source\\repos\\Lalkakkkkaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\\Lalkakkkkaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\\bin\\Debug\\Оценки-{studentName}.txt");
                string filePath = $"C:\\Users\\Daniil\\source\\repos\\Lalkakkkkaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\\Lalkakkkkaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\\bin\\Debug\\Оценки-{studentName}.txt";


                if (File.Exists(filePath))
                {
                    File.Delete(filePath);
                }
            }
            else
            {
                MessageBox.Show("Выберите ученика для удаления", "Внимание");
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {

            if (listBox1.SelectedIndex != -1)
            {
                string studentName = listBox1.SelectedItem.ToString();


                if (!string.IsNullOrWhiteSpace(textBox3.Text) &&
                    !string.IsNullOrWhiteSpace(textBox2.Text) &&
                    !string.IsNullOrWhiteSpace(textBox1.Text))
                {

                    string grades = $"{studentName}: Математика - {textBox1.Text}, Биология - {textBox2.Text}, Практика - {textBox3.Text}";


                    File.Delete ($"C:\\Users\\Daniil\\source\\repos\\Lalkakkkkaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\\Lalkakkkkaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\\bin\\Debug\\Оценки-{studentName}.txt");
                    string filePath = $"C:\\Users\\Daniil\\source\\repos\\Lalkakkkkaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\\Lalkakkkkaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\\bin\\Debug\\Оценки-{studentName}.txt";


                    DialogResult result = MessageBox.Show("Хотите сохранить оценки в файл?", "Сохранение оценок", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        using (StreamWriter writer = new StreamWriter(filePath, true))
                        {
                            writer.WriteLine(grades);
                        }

                        MessageBox.Show("Оценки сохранены в файл", "Успешно");
                    }
                }
                else
                {
                    MessageBox.Show("Введите оценки перед сохранением", "Внимание");
                }
            }
        }



        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ClearGrades()
        {
            textBox3.Text = "";
            textBox2.Text = "";
            textBox1.Text = "";
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }
        private void SetTextBoxBackgroundColor(System.Windows.Forms.TextBox textBox, string grade)
        {
            switch (grade)
            {
                case "5":
                    textBox.BackColor = Color.Green;
                    break;
                case "4":
                    textBox.BackColor = Color.Green;
                    break;
                case "3":
                    textBox.BackColor = Color.Red;
                    break;
                case "2":
                    textBox.BackColor = Color.Red;
                    break;
                default:
                    textBox.BackColor = SystemColors.Window;
                    break;
            }
        }



        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            SetTextBoxBackgroundColor(textBox1, textBox1.Text);
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            SetTextBoxBackgroundColor(textBox2, textBox2.Text);
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            SetTextBoxBackgroundColor(textBox3, textBox3.Text);
        }

        private void textBox_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
        }

        private void textBox_TextChanged(object sender, EventArgs e)
        {
            System.Windows.Forms.TextBox textBox = (System.Windows.Forms.TextBox)sender;


            if (!IsValidGrade(textBox.Text))
            {
                textBox.Text = string.Empty; // Очищаем поле
            }
        }

        private bool IsValidGrade(string input)
        {
            // Проверяем, что введенное значение является одним из допустимых
            return input == "2" || input == "3" || input == "4" || input == "5";
        }

        private void AttachEventHandlers()
        {
            textBox1.KeyPress += textBox_KeyPress;
            textBox2.KeyPress += textBox_KeyPress;
            textBox3.KeyPress += textBox_KeyPress;

            textBox1.TextChanged += textBox_TextChanged;
            textBox2.TextChanged += textBox_TextChanged;
            textBox3.TextChanged += textBox_TextChanged;
        }
    }
}