﻿using System;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.Drawing;

namespace pogoda2
{
    public partial class Form1 : Form
    {
        private const string ApiKey = "d397a995d6b587ba479889ad3dc3cf56";
        private const string ApiLang = "&lang=ru";
        private const string ApiBaseUrl = "http://api.openweathermap.org/data/2.5/weather";

        private double temperature;
        private int humidity;
        private double pressure;
        private dynamic fast;
        private string city;
        private string description;

        public Form1()
        {
            InitializeComponent();
            this.FormClosing += Form1_FormClosing;
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            city = textBox1.Text;
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    string apiUrl = $"{ApiBaseUrl}?q={city}&appid={ApiKey}{ApiLang}&units=metric";
                    HttpResponseMessage response = await client.GetAsync(apiUrl);

                    if (response.IsSuccessStatusCode)
                    {
                        string json = await response.Content.ReadAsStringAsync();
                        dynamic weatherData = JsonConvert.DeserializeObject(json);

                        // Получение температуры, влажности и давления
                        temperature = weatherData.main.temp;
                        humidity = weatherData.main.humidity;
                        pressure = weatherData.main.pressure * 0.750062;
                        fast = weatherData.weather[0];

                        // Обновление меток на форме
                        UpdateLabels();

                        // Обновляем переменную description
                        description = fast.description;

                        // Загрузка изображения в PictureBox
                        string iconCode = weatherData.weather[0].icon;
                        string imageUrl = $"http://openweathermap.org/img/w/{iconCode}.png";
                        await LoadImageAsync(client, imageUrl);
                    }
                    else
                    {
                        MessageBox.Show($"Ошибка при выполнении запроса: {response.StatusCode}");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Произошла ошибка: {ex.Message}");
                }
            }
            ChangeButtonColor((Button)sender);
        }

        private void ChangeButtonColor(Button button)
        {
            switch (button.Name)
            {
                case "button1":
                    button.BackColor = Color.Green;
                    break;
                default:
                    break;
            }
        }

        private void UpdateLabels()
        {
            label6.Text = $"Температура: {temperature}°C";
            label7.Text = $"Влажность: {humidity}%";
            label8.Text = $"Давление: {pressure.ToString("F2")} ММ рт. ст.";
            label5.Text = $"Описание погоды: {fast.description}";
        }

        private async Task LoadImageAsync(HttpClient client, string imageUrl)
        {
            try
            {
                using (var stream = await client.GetStreamAsync(imageUrl))
                {
                    pictureBox1.Image = Image.FromStream(stream);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке изображения: {ex.Message}");
            }
        }

        private void SaveResultToFile(string filePath, string content)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    writer.Write(content);
                }

                MessageBox.Show($"Результат сохранен в файл: {filePath}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении в файл: {ex.Message}");
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            

            if (string.IsNullOrEmpty(textBox1.Text))
            {
                return;
            }
            DialogResult result = MessageBox.Show("Хотите сохранить результат перед закрытием?", "Предупреждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question);



            if (result == DialogResult.Yes)
            {
                SaveResultToFile($"{city}_weather_result.txt", $"Город: {city} \nТемпература: {temperature}°C \nВлажность: {humidity}% \nДавление: {pressure.ToString("F2")} ММ рт. ст. \nПогода: {description}");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
